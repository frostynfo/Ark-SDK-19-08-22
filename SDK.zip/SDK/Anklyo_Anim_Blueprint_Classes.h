﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Classes
	// --------------------------------------------------
	/**
	 * AnimBlueprintGeneratedClass Anklyo_Anim_Blueprint.Anklyo-Anim-Blueprint_C
	 * Size -> 0x0000 (FullSize[0x1630] - InheritedSize[0x1630])
	 */
	class UAnklyo_Anim_Blueprint_C : public UDinoBlueprintBase_RootBoneName_C
	{
	public:
		void ExecuteUbergraph_Anklyo_Anim_Blueprint(int32_t EntryPoint);
		static UClass* StaticClass();
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
