﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function AIStateWanderOnLand.AIStateWanderOnLand_C.FindTargetAreas
	 */
	struct UAIStateWanderOnLand_C_FindTargetAreas_Params
	{
	public:
		bool                                                       found;                                                   // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

	/**
	 * Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnCanUseStateEvent
	 */
	struct UAIStateWanderOnLand_C_OnCanUseStateEvent_Params
	{
	public:
		bool                                                       ReturnValue;                                             // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor)
	};

	/**
	 * Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnEndEvent
	 */
	struct UAIStateWanderOnLand_C_OnEndEvent_Params
	{	};

	/**
	 * Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnTickEvent
	 */
	struct UAIStateWanderOnLand_C_OnTickEvent_Params
	{
	public:
		float                                                      DeltaSeconds;                                            // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

	/**
	 * Function AIStateWanderOnLand.AIStateWanderOnLand_C.UpgradePawnAcceleration
	 */
	struct UAIStateWanderOnLand_C_UpgradePawnAcceleration_Params
	{
	public:
		bool                                                       Upgrade;                                                 // 0x0000(0x0001)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

	/**
	 * Function AIStateWanderOnLand.AIStateWanderOnLand_C.GetRandomTarget
	 */
	struct UAIStateWanderOnLand_C_GetRandomTarget_Params
	{
	public:
		class ATargetArea*                                         returnTarget;                                            // 0x0000(0x0008)  (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

	/**
	 * Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnBeginEvent
	 */
	struct UAIStateWanderOnLand_C_OnBeginEvent_Params
	{
	public:
		class UPrimalAIState*                                      InParentState;                                           // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

	/**
	 * Function AIStateWanderOnLand.AIStateWanderOnLand_C.ExecuteUbergraph_AIStateWanderOnLand
	 */
	struct UAIStateWanderOnLand_C_ExecuteUbergraph_AIStateWanderOnLand_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
