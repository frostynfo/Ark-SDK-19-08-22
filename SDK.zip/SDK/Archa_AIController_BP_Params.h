﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function Archa_AIController_BP.Archa_AIController_BP_C.UserConstructionScript
	 */
	struct AArcha_AIController_BP_C_UserConstructionScript_Params
	{	};

	/**
	 * Function Archa_AIController_BP.Archa_AIController_BP_C.ExecuteUbergraph_Archa_AIController_BP
	 */
	struct AArcha_AIController_BP_C_ExecuteUbergraph_Archa_AIController_BP_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
