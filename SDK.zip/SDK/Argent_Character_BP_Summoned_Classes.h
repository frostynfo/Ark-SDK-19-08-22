﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Classes
	// --------------------------------------------------
	/**
	 * BlueprintGeneratedClass Argent_Character_BP_Summoned.Argent_Character_BP_Summoned_C
	 * Size -> 0x0000 (FullSize[0x22E8] - InheritedSize[0x22E8])
	 */
	class AArgent_Character_BP_Summoned_C : public AArgent_Character_BP_C
	{
	public:
		void UserConstructionScript();
		void ExecuteUbergraph_Argent_Character_BP_Summoned(int32_t EntryPoint);
		static UClass* StaticClass();
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
