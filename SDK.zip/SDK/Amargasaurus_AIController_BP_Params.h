﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function Amargasaurus_AIController_BP.Amargasaurus_AIController_BP_C.BPGetTargetingDesire
	 */
	struct AAmargasaurus_AIController_BP_C_BPGetTargetingDesire_Params
	{
	public:
		class AActor*                                              forTarget;                                               // 0x0000(0x0008)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
		float                                                      ForTargetingDesireValue;                                 // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
		float                                                      ReturnValue;                                             // 0x0000(0x0004)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor)
	};

	/**
	 * Function Amargasaurus_AIController_BP.Amargasaurus_AIController_BP_C.UserConstructionScript
	 */
	struct AAmargasaurus_AIController_BP_C_UserConstructionScript_Params
	{	};

	/**
	 * Function Amargasaurus_AIController_BP.Amargasaurus_AIController_BP_C.ExecuteUbergraph_Amargasaurus_AIController_BP
	 */
	struct AAmargasaurus_AIController_BP_C_ExecuteUbergraph_Amargasaurus_AIController_BP_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
