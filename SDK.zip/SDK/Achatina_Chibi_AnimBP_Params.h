﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function Achatina_Chibi_AnimBP.Achatina_Chibi_AnimBP_C.ExecuteUbergraph_Achatina_Chibi_AnimBP
	 */
	struct UAchatina_Chibi_AnimBP_C_ExecuteUbergraph_Achatina_Chibi_AnimBP_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
