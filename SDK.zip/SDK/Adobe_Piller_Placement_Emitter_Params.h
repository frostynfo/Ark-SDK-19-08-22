﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function Adobe_Piller_Placement_Emitter.Adobe_Piller_Placement_Emitter_C.UserConstructionScript
	 */
	struct AAdobe_Piller_Placement_Emitter_C_UserConstructionScript_Params
	{	};

	/**
	 * Function Adobe_Piller_Placement_Emitter.Adobe_Piller_Placement_Emitter_C.ExecuteUbergraph_Adobe_Piller_Placement_Emitter
	 */
	struct AAdobe_Piller_Placement_Emitter_C_ExecuteUbergraph_Adobe_Piller_Placement_Emitter_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
