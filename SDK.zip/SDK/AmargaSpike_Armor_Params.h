﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function AmargaSpike_Armor.AmargaSpike_Armor_C.UserConstructionScript
	 */
	struct AAmargaSpike_Armor_C_UserConstructionScript_Params
	{	};

	/**
	 * Function AmargaSpike_Armor.AmargaSpike_Armor_C.ExecuteUbergraph_AmargaSpike_Armor
	 */
	struct AAmargaSpike_Armor_C_ExecuteUbergraph_AmargaSpike_Armor_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
