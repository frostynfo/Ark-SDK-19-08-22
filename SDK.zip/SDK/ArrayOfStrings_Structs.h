﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * UserDefinedStruct ArrayOfStrings.ArrayOfStrings
	 * Size -> 0x0010
	 */
	struct FArrayOfStrings
	{
	public:
		TArray<class FString>                                      StringArray_3_042E4BCC4FCFD13EE6278BB57BF57A53;          // 0x0000(0x0010) Edit, BlueprintVisible, ZeroConstructor
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
