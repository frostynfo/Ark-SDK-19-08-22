﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Classes
	// --------------------------------------------------
	/**
	 * BlueprintGeneratedClass Angler_Character_BP_Aberrant.Angler_Character_BP_Aberrant_C
	 * Size -> 0x0000 (FullSize[0x22A0] - InheritedSize[0x22A0])
	 */
	class AAngler_Character_BP_Aberrant_C : public AAngler_Character_BP_C
	{
	public:
		void UserConstructionScript();
		void ExecuteUbergraph_Angler_Character_BP_Aberrant(int32_t EntryPoint);
		static UClass* StaticClass();
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
