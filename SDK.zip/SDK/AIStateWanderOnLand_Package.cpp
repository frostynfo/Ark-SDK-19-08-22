﻿/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#include "pch.h"

namespace CG
{
	// --------------------------------------------------
	// # Structs Functions
	// --------------------------------------------------
	/**
	 * Function:
	 * 		RVA    -> 0x021C8450
	 * 		Name   -> Function AIStateWanderOnLand.AIStateWanderOnLand_C.FindTargetAreas
	 * 		Flags  -> (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
	 * Parameters:
	 * 		bool                                               found                                                      (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	 */
	void UAIStateWanderOnLand_C::FindTargetAreas(bool* found)
	{
		static UFunction* fn = nullptr;
		if (!fn)
			fn = UObject::FindObject<UFunction>("Function AIStateWanderOnLand.AIStateWanderOnLand_C.FindTargetAreas");
		
		UAIStateWanderOnLand_C_FindTargetAreas_Params params {};
		
		auto flags = fn->FunctionFlags;
		UObject::ProcessEvent(fn, &params);
		fn->FunctionFlags = flags;
		
		if (found != nullptr)
			*found = params.found;
	}

	/**
	 * Function:
	 * 		RVA    -> 0x021C8450
	 * 		Name   -> Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnCanUseStateEvent
	 * 		Flags  -> (Event, Public, HasOutParms, BlueprintCallable, BlueprintEvent)
	 */
	bool UAIStateWanderOnLand_C::OnCanUseStateEvent()
	{
		static UFunction* fn = nullptr;
		if (!fn)
			fn = UObject::FindObject<UFunction>("Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnCanUseStateEvent");
		
		UAIStateWanderOnLand_C_OnCanUseStateEvent_Params params {};
		
		auto flags = fn->FunctionFlags;
		UObject::ProcessEvent(fn, &params);
		fn->FunctionFlags = flags;
		
		return params.ReturnValue;
	}

	/**
	 * Function:
	 * 		RVA    -> 0x021C8450
	 * 		Name   -> Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnEndEvent
	 * 		Flags  -> (Event, Public, BlueprintCallable, BlueprintEvent)
	 */
	void UAIStateWanderOnLand_C::OnEndEvent()
	{
		static UFunction* fn = nullptr;
		if (!fn)
			fn = UObject::FindObject<UFunction>("Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnEndEvent");
		
		UAIStateWanderOnLand_C_OnEndEvent_Params params {};
		
		auto flags = fn->FunctionFlags;
		UObject::ProcessEvent(fn, &params);
		fn->FunctionFlags = flags;
	}

	/**
	 * Function:
	 * 		RVA    -> 0x021C8450
	 * 		Name   -> Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnTickEvent
	 * 		Flags  -> (Event, Public, BlueprintCallable, BlueprintEvent)
	 * Parameters:
	 * 		float                                              DeltaSeconds                                               (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	 */
	void UAIStateWanderOnLand_C::OnTickEvent(float DeltaSeconds)
	{
		static UFunction* fn = nullptr;
		if (!fn)
			fn = UObject::FindObject<UFunction>("Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnTickEvent");
		
		UAIStateWanderOnLand_C_OnTickEvent_Params params {};
		params.DeltaSeconds = DeltaSeconds;
		
		auto flags = fn->FunctionFlags;
		UObject::ProcessEvent(fn, &params);
		fn->FunctionFlags = flags;
	}

	/**
	 * Function:
	 * 		RVA    -> 0x021C8450
	 * 		Name   -> Function AIStateWanderOnLand.AIStateWanderOnLand_C.UpgradePawnAcceleration
	 * 		Flags  -> (Public, BlueprintCallable, BlueprintEvent)
	 * Parameters:
	 * 		bool                                               Upgrade                                                    (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	 */
	void UAIStateWanderOnLand_C::UpgradePawnAcceleration(bool Upgrade)
	{
		static UFunction* fn = nullptr;
		if (!fn)
			fn = UObject::FindObject<UFunction>("Function AIStateWanderOnLand.AIStateWanderOnLand_C.UpgradePawnAcceleration");
		
		UAIStateWanderOnLand_C_UpgradePawnAcceleration_Params params {};
		params.Upgrade = Upgrade;
		
		auto flags = fn->FunctionFlags;
		UObject::ProcessEvent(fn, &params);
		fn->FunctionFlags = flags;
	}

	/**
	 * Function:
	 * 		RVA    -> 0x021C8450
	 * 		Name   -> Function AIStateWanderOnLand.AIStateWanderOnLand_C.GetRandomTarget
	 * 		Flags  -> (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
	 * Parameters:
	 * 		class ATargetArea*                                 returnTarget                                               (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	 */
	void UAIStateWanderOnLand_C::GetRandomTarget(class ATargetArea** returnTarget)
	{
		static UFunction* fn = nullptr;
		if (!fn)
			fn = UObject::FindObject<UFunction>("Function AIStateWanderOnLand.AIStateWanderOnLand_C.GetRandomTarget");
		
		UAIStateWanderOnLand_C_GetRandomTarget_Params params {};
		
		auto flags = fn->FunctionFlags;
		UObject::ProcessEvent(fn, &params);
		fn->FunctionFlags = flags;
		
		if (returnTarget != nullptr)
			*returnTarget = params.returnTarget;
	}

	/**
	 * Function:
	 * 		RVA    -> 0x021C8450
	 * 		Name   -> Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnBeginEvent
	 * 		Flags  -> (Event, Public, BlueprintCallable, BlueprintEvent)
	 * Parameters:
	 * 		class UPrimalAIState*                              InParentState                                              (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	 */
	void UAIStateWanderOnLand_C::OnBeginEvent(class UPrimalAIState* InParentState)
	{
		static UFunction* fn = nullptr;
		if (!fn)
			fn = UObject::FindObject<UFunction>("Function AIStateWanderOnLand.AIStateWanderOnLand_C.OnBeginEvent");
		
		UAIStateWanderOnLand_C_OnBeginEvent_Params params {};
		params.InParentState = InParentState;
		
		auto flags = fn->FunctionFlags;
		UObject::ProcessEvent(fn, &params);
		fn->FunctionFlags = flags;
	}

	/**
	 * Function:
	 * 		RVA    -> 0x021C8450
	 * 		Name   -> Function AIStateWanderOnLand.AIStateWanderOnLand_C.ExecuteUbergraph_AIStateWanderOnLand
	 * 		Flags  -> ()
	 * Parameters:
	 * 		int32_t                                            EntryPoint                                                 (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	 */
	void UAIStateWanderOnLand_C::ExecuteUbergraph_AIStateWanderOnLand(int32_t EntryPoint)
	{
		static UFunction* fn = nullptr;
		if (!fn)
			fn = UObject::FindObject<UFunction>("Function AIStateWanderOnLand.AIStateWanderOnLand_C.ExecuteUbergraph_AIStateWanderOnLand");
		
		UAIStateWanderOnLand_C_ExecuteUbergraph_AIStateWanderOnLand_Params params {};
		params.EntryPoint = EntryPoint;
		
		auto flags = fn->FunctionFlags;
		UObject::ProcessEvent(fn, &params);
		fn->FunctionFlags = flags;
	}

	/**
	 * Function:
	 * 		RVA    -> 0x00000000
	 * 		Name   -> PredefindFunction UAIStateWanderOnLand_C.StaticClass
	 * 		Flags  -> (Predefined, Static)
	 */
	UClass* UAIStateWanderOnLand_C::StaticClass()
	{
		static UClass* ptr = nullptr;
		if (!ptr)
			ptr = UObject::FindClass("BlueprintGeneratedClass AIStateWanderOnLand.AIStateWanderOnLand_C");
		return ptr;
	}

}


