﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function Argent_Character_BP_Summoned.Argent_Character_BP_Summoned_C.UserConstructionScript
	 */
	struct AArgent_Character_BP_Summoned_C_UserConstructionScript_Params
	{	};

	/**
	 * Function Argent_Character_BP_Summoned.Argent_Character_BP_Summoned_C.ExecuteUbergraph_Argent_Character_BP_Summoned
	 */
	struct AArgent_Character_BP_Summoned_C_ExecuteUbergraph_Argent_Character_BP_Summoned_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
