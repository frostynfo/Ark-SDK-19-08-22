﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Classes
	// --------------------------------------------------
	/**
	 * AnimBlueprintGeneratedClass Angler_Anim_BP.Angler_Anim_BP_C
	 * Size -> 0x0000 (FullSize[0x1198] - InheritedSize[0x1198])
	 */
	class UAngler_Anim_BP_C : public UDinoBlueprintBase_RootTransform_C
	{
	public:
		void ExecuteUbergraph_Angler_Anim_BP(int32_t EntryPoint);
		static UClass* StaticClass();
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
