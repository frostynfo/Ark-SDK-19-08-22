﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Classes
	// --------------------------------------------------
	/**
	 * AnimBlueprintGeneratedClass Archaeopteryx_Chibi_AnimBP.Archaeopteryx_Chibi_AnimBP_C
	 * Size -> 0x0000 (FullSize[0x06C8] - InheritedSize[0x06C8])
	 */
	class UArchaeopteryx_Chibi_AnimBP_C : public URaptor_new_Chibi_AnimBP_BASE_C
	{
	public:
		void ExecuteUbergraph_Archaeopteryx_Chibi_AnimBP(int32_t EntryPoint);
		static UClass* StaticClass();
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
