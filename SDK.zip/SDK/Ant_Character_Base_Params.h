﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function Ant_Character_Base.Ant_Character_Base_C.UserConstructionScript
	 */
	struct AAnt_Character_Base_C_UserConstructionScript_Params
	{	};

	/**
	 * Function Ant_Character_Base.Ant_Character_Base_C.ExecuteUbergraph_Ant_Character_Base
	 */
	struct AAnt_Character_Base_C_ExecuteUbergraph_Ant_Character_Base_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
