﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function Anklyo-Anim-Blueprint.Anklyo-Anim-Blueprint_C.ExecuteUbergraph_Anklyo-Anim-Blueprint
	 */
	struct UAnklyo_Anim_Blueprint_C_ExecuteUbergraph_Anklyo_Anim_Blueprint_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
