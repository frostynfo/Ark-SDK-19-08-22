﻿/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#include "pch.h"

namespace CG
{
	// --------------------------------------------------
	// # Structs Functions
	// --------------------------------------------------
	/**
	 * Function:
	 * 		RVA    -> 0x021C8450
	 * 		Name   -> Function Anklyo-Anim-Blueprint.Anklyo-Anim-Blueprint_C.ExecuteUbergraph_Anklyo-Anim-Blueprint
	 * 		Flags  -> ()
	 * Parameters:
	 * 		int32_t                                            EntryPoint                                                 (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	 */
	void UAnklyo_Anim_Blueprint_C::ExecuteUbergraph_Anklyo_Anim_Blueprint(int32_t EntryPoint)
	{
		static UFunction* fn = nullptr;
		if (!fn)
			fn = UObject::FindObject<UFunction>("Function Anklyo-Anim-Blueprint.Anklyo-Anim-Blueprint_C.ExecuteUbergraph_Anklyo-Anim-Blueprint");
		
		UAnklyo_Anim_Blueprint_C_ExecuteUbergraph_Anklyo_Anim_Blueprint_Params params {};
		params.EntryPoint = EntryPoint;
		
		auto flags = fn->FunctionFlags;
		UObject::ProcessEvent(fn, &params);
		fn->FunctionFlags = flags;
	}

	/**
	 * Function:
	 * 		RVA    -> 0x00000000
	 * 		Name   -> PredefindFunction UAnklyo_Anim_Blueprint_C.StaticClass
	 * 		Flags  -> (Predefined, Static)
	 */
	UClass* UAnklyo_Anim_Blueprint_C::StaticClass()
	{
		static UClass* ptr = nullptr;
		if (!ptr)
			ptr = UObject::FindClass("AnimBlueprintGeneratedClass Anklyo_Anim_Blueprint.Anklyo-Anim-Blueprint_C");
		return ptr;
	}

}


