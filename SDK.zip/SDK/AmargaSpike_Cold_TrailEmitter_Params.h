﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function AmargaSpike_Cold_TrailEmitter.AmargaSpike_Cold_TrailEmitter_C.ReceiveBeginPlay
	 */
	struct AAmargaSpike_Cold_TrailEmitter_C_ReceiveBeginPlay_Params
	{	};

	/**
	 * Function AmargaSpike_Cold_TrailEmitter.AmargaSpike_Cold_TrailEmitter_C.InWaterCheck
	 */
	struct AAmargaSpike_Cold_TrailEmitter_C_InWaterCheck_Params
	{	};

	/**
	 * Function AmargaSpike_Cold_TrailEmitter.AmargaSpike_Cold_TrailEmitter_C.UserConstructionScript
	 */
	struct AAmargaSpike_Cold_TrailEmitter_C_UserConstructionScript_Params
	{	};

	/**
	 * Function AmargaSpike_Cold_TrailEmitter.AmargaSpike_Cold_TrailEmitter_C.ExecuteUbergraph_AmargaSpike_Cold_TrailEmitter
	 */
	struct AAmargaSpike_Cold_TrailEmitter_C_ExecuteUbergraph_AmargaSpike_Cold_TrailEmitter_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
