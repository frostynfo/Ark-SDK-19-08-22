﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function Amargasaurus_AnimBP.Amargasaurus_AnimBP_C.ExecuteUbergraph_Amargasaurus_AnimBP
	 */
	struct UAmargasaurus_AnimBP_C_ExecuteUbergraph_Amargasaurus_AnimBP_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
