﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Classes
	// --------------------------------------------------
	/**
	 * BlueprintGeneratedClass AmargaSpike_Armor.AmargaSpike_Armor_C
	 * Size -> 0x0000 (FullSize[0x1088] - InheritedSize[0x1088])
	 */
	class AAmargaSpike_Armor_C : public AAmargaSpike_C
	{
	public:
		void UserConstructionScript();
		void ExecuteUbergraph_AmargaSpike_Armor(int32_t EntryPoint);
		static UClass* StaticClass();
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
