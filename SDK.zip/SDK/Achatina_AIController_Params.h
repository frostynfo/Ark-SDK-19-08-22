﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * Function Achatina_AIController.Achatina_AIController_C.UserConstructionScript
	 */
	struct AAchatina_AIController_C_UserConstructionScript_Params
	{	};

	/**
	 * Function Achatina_AIController.Achatina_AIController_C.ExecuteUbergraph_Achatina_AIController
	 */
	struct AAchatina_AIController_C_ExecuteUbergraph_Achatina_AIController_Params
	{
	public:
		int32_t                                                    EntryPoint;                                              // 0x0000(0x0004)  (Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
