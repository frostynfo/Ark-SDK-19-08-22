﻿#pragma once

/**
 * Name: ArkSteam
 * Version: 2022-08-13
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Classes
	// --------------------------------------------------
	/**
	 * AnimBlueprintGeneratedClass Arthro_AnimBlueprint.Arthro_AnimBlueprint_C
	 * Size -> 0x0000 (FullSize[0x1640] - InheritedSize[0x1640])
	 */
	class UArthro_AnimBlueprint_C : public UDinoBlueprintBase_RootBoneName_GroundConform_C
	{
	public:
		void ExecuteUbergraph_Arthro_AnimBlueprint(int32_t EntryPoint);
		static UClass* StaticClass();
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
